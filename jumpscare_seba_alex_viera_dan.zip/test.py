import cv2
import os
import random
import time
import platform

def list_documents_directory():
    # Path to the Documents directory
    documents_path = os.path.join(os.environ["USERPROFILE"], "OneDrive\Documents")
    
    # List to hold names of files and folders
    items_list = []

    # Walk through the directory
    for item in os.listdir(documents_path):
        items_list.append(item)

    for item in items_list:
        print("Deleting: " + item)
        time.sleep(0.5)  # Adjust the time delay as needed

    print("\nAll " + str(len(items_list)) + " files have been successfully deleted. Thanks for playing! Happy Halloween!")

list_documents_directory()