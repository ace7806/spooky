import tkinter as tk
from tkinter import PhotoImage
import pygame  # For playing sound

# Initialize pygame for sound
pygame.mixer.init()

# Set up the main window
root = tk.Tk()
root.title("Image and Sound Example")
root.attributes("-fullscreen", True)  # Set window to full-screen mode
root.config(bg="black")  # Set background color to black

# Load images for buttons (replace with the paths to your images)
enter_image = PhotoImage(file="png-clipart-door-spooky-door-s-angle-building-thumbnail.png")  # Image for the "Enter" button
toggle_image_1 = PhotoImage(file="png-transparent-light-bulb-illustration-incandescent-light-bulb-lamp-bulb-candle-product-light-thumbnail.png")  # First toggle image
toggle_image_2 = PhotoImage(file="png-clipart-creative-bulb-lightbulb-energy-saving-lamps-thumbnail.png")  # Second toggle image
display_image = PhotoImage(file="png-transparent-scary-face.png")  # Image displayed by "New Button 1"

# Load sound file (replace with the path to your sound file)
sound_path = "WhatsApp_Audio_2024-10-29_at_20.42.13.mp3"

# Variable to keep track of which image is currently displayed
toggle_state = 0  # 0 -> first image, 1 -> second image

# Function to handle the "Enter" button click
def on_enter_click():
    # Hide the "Enter" button
    enter_button.pack_forget()
    # Show the two new buttons
    new_button1.pack()
    toggle_button.pack()

# Function to toggle between images on the toggle button
def on_toggle_click():
    global toggle_state
    # Toggle the state
    if toggle_state == 0:
        toggle_button.config(image=toggle_image_2)
        toggle_state = 1
    else:
        toggle_button.config(image=toggle_image_1)
        toggle_state = 0

# Function to display an image and play a sound when "New Button 1" is clicked
def on_new_button1_click():
    # Display the image on the screen
    display_label.config(image=display_image)
    display_label.pack(pady=10)
    # Play the sound
    pygame.mixer.music.load(sound_path)
    pygame.mixer.music.play()
    toggle_button.destroy()

# "Enter" button with an image
enter_button = tk.Button(root, text="Enter", image=enter_image, compound="top", command=on_enter_click, bg="black", fg="white")
enter_button.pack(pady=20)

# New buttons (hidden initially)
new_button1 = tk.Button(root, text="No Jump Scare Button", command=on_new_button1_click, bg="black", fg="white")
toggle_button = tk.Button(root, image=toggle_image_1, command=on_toggle_click, bg="black")

# Label to display the image when "New Button 1" is clicked (initially empty)
display_label = tk.Label(root, bg="black")

# Start the Tkinter event loop
root.mainloop()
